--
-- PostgreSQL database dump
--

-- Dumped from database version 17.2
-- Dumped by pg_dump version 17.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: backup_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.backup_logs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    type character varying(20) NOT NULL,
    filename character varying(255),
    file_size bigint,
    status character varying(20) DEFAULT 'SUCCESS'::character varying,
    created_by uuid,
    company_id uuid,
    error_message text,
    storage_location character varying(50) DEFAULT 'local'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.backup_logs OWNER TO postgres;

--
-- Name: companies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.companies (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    address text,
    email character varying(255),
    phone character varying(50),
    currency character varying(10) DEFAULT 'INR'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    gstin character varying(15),
    state character varying(50)
);


ALTER TABLE public.companies OWNER TO postgres;

--
-- Name: company_users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.company_users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    company_id uuid,
    user_id uuid,
    role character varying(50) DEFAULT 'viewer'::character varying
);


ALTER TABLE public.company_users OWNER TO postgres;

--
-- Name: email_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.email_logs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    invoice_id uuid,
    recipient character varying(255) NOT NULL,
    cc character varying(255),
    subject text,
    sent_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    status character varying(20) DEFAULT 'SENT'::character varying
);


ALTER TABLE public.email_logs OWNER TO postgres;

--
-- Name: financial_years; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.financial_years (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    company_id uuid,
    name character varying(50) NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    is_active boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.financial_years OWNER TO postgres;

--
-- Name: invoice_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.invoice_items (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    invoice_id uuid,
    item_id uuid,
    description text,
    quantity numeric(15,3) DEFAULT 0.000,
    rate numeric(15,2) DEFAULT 0.00,
    amount numeric(15,2) DEFAULT 0.00,
    tax_rate numeric(5,2) DEFAULT 0.00,
    tax_amount numeric(15,2) DEFAULT 0.00,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    discount_percent numeric(5,2) DEFAULT 0.00,
    discount_amount numeric(15,2) DEFAULT 0.00,
    cgst_rate numeric(5,2) DEFAULT 0.00,
    cgst_amount numeric(15,2) DEFAULT 0.00,
    sgst_rate numeric(5,2) DEFAULT 0.00,
    sgst_amount numeric(15,2) DEFAULT 0.00,
    igst_rate numeric(5,2) DEFAULT 0.00,
    igst_amount numeric(15,2) DEFAULT 0.00,
    taxable_amount numeric(15,2) DEFAULT 0.00,
    total_amount numeric(15,2) DEFAULT 0.00
);


ALTER TABLE public.invoice_items OWNER TO postgres;

--
-- Name: invoices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.invoices (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    company_id uuid,
    voucher_id uuid,
    party_ledger_id uuid,
    sales_ledger_id uuid,
    invoice_number character varying(50) NOT NULL,
    date date NOT NULL,
    due_date date,
    type character varying(20) NOT NULL,
    subtotal numeric(15,2) DEFAULT 0.00,
    tax_total numeric(15,2) DEFAULT 0.00,
    grand_total numeric(15,2) DEFAULT 0.00,
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    discount_percent numeric(5,2) DEFAULT 0.00,
    discount_amount numeric(15,2) DEFAULT 0.00,
    paid_amount numeric(15,2) DEFAULT 0.00,
    outstanding_amount numeric(15,2) DEFAULT 0.00,
    payment_status character varying(20) DEFAULT 'UNPAID'::character varying
);


ALTER TABLE public.invoices OWNER TO postgres;

--
-- Name: items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.items (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    company_id uuid,
    name character varying(255) NOT NULL,
    hsn_code character varying(50),
    unit_id uuid,
    description text,
    tax_rate numeric(5,2) DEFAULT 0.00,
    sales_rate numeric(15,2) DEFAULT 0.00,
    purchase_rate numeric(15,2) DEFAULT 0.00,
    opening_quantity numeric(15,3) DEFAULT 0.000,
    current_quantity numeric(15,3) DEFAULT 0.000,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.items OWNER TO postgres;

--
-- Name: ledger_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ledger_groups (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    company_id uuid,
    name character varying(255) NOT NULL,
    parent_id uuid,
    type character varying(50) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.ledger_groups OWNER TO postgres;

--
-- Name: ledgers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ledgers (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    company_id uuid,
    group_id uuid,
    name character varying(255) NOT NULL,
    opening_balance numeric(15,2) DEFAULT 0.00,
    opening_balance_type character varying(10) DEFAULT 'Dr'::character varying,
    current_balance numeric(15,2) DEFAULT 0.00,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    gstin character varying(15),
    state character varying(50)
);


ALTER TABLE public.ledgers OWNER TO postgres;

--
-- Name: payments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payments (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    company_id uuid,
    invoice_id uuid,
    voucher_id uuid,
    payment_date date NOT NULL,
    amount numeric(15,2) NOT NULL,
    payment_mode character varying(50),
    reference_number character varying(100),
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.payments OWNER TO postgres;

--
-- Name: recurring_invoice_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recurring_invoice_items (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    recurring_invoice_id uuid,
    item_id uuid,
    description text,
    quantity numeric(15,3) NOT NULL,
    rate numeric(15,2) NOT NULL,
    discount_percent numeric(5,2) DEFAULT 0.00
);


ALTER TABLE public.recurring_invoice_items OWNER TO postgres;

--
-- Name: recurring_invoices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recurring_invoices (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    company_id uuid,
    party_ledger_id uuid,
    sales_ledger_id uuid,
    type character varying(20) NOT NULL,
    frequency character varying(20) NOT NULL,
    start_date date NOT NULL,
    end_date date,
    next_invoice_date date NOT NULL,
    invoice_number_prefix character varying(50),
    discount_percent numeric(5,2) DEFAULT 0.00,
    notes text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.recurring_invoices OWNER TO postgres;

--
-- Name: restore_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.restore_logs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    backup_filename character varying(255),
    type character varying(20) NOT NULL,
    status character varying(20) DEFAULT 'SUCCESS'::character varying,
    restored_by uuid,
    error_message text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.restore_logs OWNER TO postgres;

--
-- Name: units; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.units (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    company_id uuid,
    name character varying(50) NOT NULL,
    symbol character varying(20) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.units OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    role character varying(50) DEFAULT 'viewer'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: voucher_entries; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.voucher_entries (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    voucher_id uuid,
    ledger_id uuid,
    amount numeric(15,2) NOT NULL,
    type character varying(10) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.voucher_entries OWNER TO postgres;

--
-- Name: voucher_types; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.voucher_types (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    company_id uuid,
    name character varying(50) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.voucher_types OWNER TO postgres;

--
-- Name: vouchers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vouchers (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    company_id uuid,
    financial_year_id uuid,
    voucher_type_id uuid,
    voucher_number character varying(50) NOT NULL,
    date date NOT NULL,
    narration text,
    total_amount numeric(15,2) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.vouchers OWNER TO postgres;

--
-- Data for Name: backup_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.backup_logs (id, type, filename, file_size, status, created_by, company_id, error_message, storage_location, created_at) FROM stdin;
231d011f-18bb-4aa8-8e17-2f0dd2846fb1	FULL	\N	\N	FAILED	ddcfa393-39ff-4157-bbf7-996f1386fe86	\N	Backup failed: Command failed: pg_dump -h localhost -p 5432 -U postgres -d cloudledger -F p -f "backups\\full\\cloudledger_full_2025-12-08T12-28-19-742Z.sql"\n'pg_dump' is not recognized as an internal or external command,\r\noperable program or batch file.\r\n	local	2025-12-08 17:58:19.82637
22ba81f5-3c5b-4d5a-8788-76ae906d3cfe	FULL	\N	\N	FAILED	ddcfa393-39ff-4157-bbf7-996f1386fe86	\N	Backup failed: Command failed: pg_dump -h localhost -p 5432 -U postgres -d cloudledger -F p -f "backups\\full\\cloudledger_full_2025-12-08T12-31-45-015Z.sql"\n'pg_dump' is not recognized as an internal or external command,\r\noperable program or batch file.\r\n	local	2025-12-08 18:01:45.115236
fc26abee-4d0e-44da-8509-1b24c69e8c03	FULL	\N	\N	FAILED	ddcfa393-39ff-4157-bbf7-996f1386fe86	\N	Backup failed: Command failed: pg_dump -h localhost -p 5432 -U postgres -d cloudledger -F p -f "backups\\full\\cloudledger_full_2025-12-08T12-34-37-218Z.sql"\n'pg_dump' is not recognized as an internal or external command,\r\noperable program or batch file.\r\n	local	2025-12-08 18:04:37.273918
a054323d-1d63-4af6-b2fe-886c83f8de82	FULL	\N	\N	FAILED	ddcfa393-39ff-4157-bbf7-996f1386fe86	\N	Backup failed: Command failed: pg_dump -h localhost -p 5432 -U postgres -d cloudledger -F p -f "backups\\full\\cloudledger_full_2025-12-08T12-34-42-172Z.sql"\n'pg_dump' is not recognized as an internal or external command,\r\noperable program or batch file.\r\n	local	2025-12-08 18:04:42.2413
3c61b31d-65c5-4f3b-98f0-9e60c255a6e2	FULL	\N	\N	FAILED	ddcfa393-39ff-4157-bbf7-996f1386fe86	\N	Backup failed: Command failed: "C:\\Program Files\\PostgreSQL\\16\\bin\\pg_dump.exe" -h localhost -p 5432 -U postgres -d cloudledger -F p -f "backups\\full\\cloudledger_full_2025-12-08T12-37-21-134Z.sql"\npg_dump: error: aborting because of server version mismatch\r\npg_dump: detail: server version: 17.2; pg_dump version: 16.9\r\n	local	2025-12-08 18:07:21.832689
a4885afa-a85a-4955-bf90-89b6ca50e89e	FULL	\N	\N	FAILED	\N	\N	Backup failed: Command failed: "C:\\Program Files\\PostgreSQL\\16\\bin\\pg_dump.exe" -h localhost -p 5432 -U postgres -d cloudledger -F p -f "backups\\full\\cloudledger_full_2025-12-08T20-30-00-108Z.sql"\npg_dump: error: aborting because of server version mismatch\r\npg_dump: detail: server version: 17.2; pg_dump version: 16.9\r\n	local	2025-12-09 02:00:01.076215
a95f4bac-64f5-4bc9-b3ec-8f56ce1c5eb9	FULL	\N	\N	FAILED	ddcfa393-39ff-4157-bbf7-996f1386fe86	\N	Backup failed: Command failed: "C:\\Program Files\\PostgreSQL\\16\\bin\\pg_dump.exe" -h localhost -p 5432 -U postgres -d cloudledger -F p -f "backups\\full\\cloudledger_full_2025-12-09T04-07-42-327Z.sql"\npg_dump: error: aborting because of server version mismatch\r\npg_dump: detail: server version: 17.2; pg_dump version: 16.9\r\n	local	2025-12-09 09:37:43.163304
5d887499-43c0-4b61-81c2-631d0a83d034	COMPANY	Fortune_Concept_2025-12-09T04-07-55-205Z.json	18171	SUCCESS	ddcfa393-39ff-4157-bbf7-996f1386fe86	b53635ba-7fac-409d-9de4-c812b2a84263	\N	local	2025-12-09 09:37:55.239917
f4a5d29b-3015-4f24-8a02-a8d82c04c062	COMPANY	Fortune_Concept_2025-12-09T04-10-36-804Z.json	18171	SUCCESS	ddcfa393-39ff-4157-bbf7-996f1386fe86	b53635ba-7fac-409d-9de4-c812b2a84263	\N	local	2025-12-09 09:40:36.811241
cf13309f-6036-4b4b-8e11-6602bd8ba6aa	FULL	\N	\N	FAILED	ddcfa393-39ff-4157-bbf7-996f1386fe86	\N	Backup failed: Command failed: "C:\\Program Files\\PostgreSQL\\16\\bin\\pg_dump.exe" -h localhost -p 5432 -U postgres -d cloudledger -F p -f "backups\\full\\cloudledger_full_2025-12-09T06-47-26-815Z.sql"\npg_dump: error: aborting because of server version mismatch\r\npg_dump: detail: server version: 17.2; pg_dump version: 16.9\r\n	local	2025-12-09 12:17:27.533147
d546cf68-1eaf-459d-9fc8-b34ff629475f	FULL	\N	\N	FAILED	ddcfa393-39ff-4157-bbf7-996f1386fe86	\N	Backup failed: Command failed: "C:\\Program Files\\PostgreSQL\\16\\bin\\pg_dump.exe" -h localhost -p 5432 -U postgres -d cloudledger -F p -f "backups\\full\\cloudledger_full_2025-12-09T06-47-32-994Z.sql"\npg_dump: error: aborting because of server version mismatch\r\npg_dump: detail: server version: 17.2; pg_dump version: 16.9\r\n	local	2025-12-09 12:17:33.142846
33263bd2-e134-4e94-80ae-0318f688f3ee	COMPANY	Fortune_Concept_2025-12-09T06-49-27-903Z.json	18171	SUCCESS	ddcfa393-39ff-4157-bbf7-996f1386fe86	b53635ba-7fac-409d-9de4-c812b2a84263	\N	local	2025-12-09 12:19:27.916742
171837a9-4610-46df-bbbe-54de4c3a81c1	FULL	\N	\N	FAILED	ddcfa393-39ff-4157-bbf7-996f1386fe86	\N	Backup failed: Command failed: "C:\\Program Files\\PostgreSQL\\16\\bin\\pg_dump.exe" -h localhost -p 5432 -U postgres -d cloudledger -F p -f "backups\\full\\cloudledger_full_2025-12-09T07-02-56-737Z.sql"\npg_dump: error: aborting because of server version mismatch\r\npg_dump: detail: server version: 17.2; pg_dump version: 16.9\r\n	local	2025-12-09 12:32:57.178382
77419feb-25e7-4c47-a097-2d03ad1c3663	COMPANY	Fortune_Concept_2025-12-09T07-03-26-677Z.json	18171	SUCCESS	ddcfa393-39ff-4157-bbf7-996f1386fe86	b53635ba-7fac-409d-9de4-c812b2a84263	\N	local	2025-12-09 12:33:26.696484
eed94210-31cf-4a61-aea8-a8262cfe3c2c	FULL	\N	\N	FAILED	ddcfa393-39ff-4157-bbf7-996f1386fe86	\N	Backup failed: Command failed: "C:\\Program Files\\PostgreSQL\\16\\bin\\pg_dump.exe" -h localhost -p 5432 -U postgres -d cloudledger -F p -f "backups\\full\\cloudledger_full_2025-12-09T07-08-59-732Z.sql"\npg_dump: error: aborting because of server version mismatch\r\npg_dump: detail: server version: 17.2; pg_dump version: 16.9\r\n	local	2025-12-09 12:39:00.340472
190b89c4-ea6b-4a96-ae57-f19f7d6b23ae	FULL	\N	\N	FAILED	ddcfa393-39ff-4157-bbf7-996f1386fe86	\N	Backup failed: Command failed: "C:\\Program Files\\PostgreSQL\\16\\bin\\pg_dump.exe" -h localhost -p 5432 -U postgres -d cloudledger -F p -f "backups\\full\\cloudledger_full_2025-12-09T07-18-16-030Z.sql"\npg_dump: error: aborting because of server version mismatch\r\npg_dump: detail: server version: 17.2; pg_dump version: 16.9\r\n	local	2025-12-09 12:48:16.205995
29e2f78a-d56f-4409-8439-d605d33fd78a	FULL	\N	\N	FAILED	ddcfa393-39ff-4157-bbf7-996f1386fe86	\N	Backup failed: Command failed: "C:\\Program Files\\PostgreSQL\\16\\bin\\pg_dump.exe" -h localhost -p 5432 -U postgres -d cloudledger -F p -f "backups\\full\\cloudledger_full_2025-12-09T07-24-07-513Z.sql"\npg_dump: error: aborting because of server version mismatch\r\npg_dump: detail: server version: 17.2; pg_dump version: 16.9\r\n	local	2025-12-09 12:54:07.699272
197e7bc8-39cb-4a52-a6e9-955a5f59bc5f	COMPANY	Fortune_Concept_2025-12-09T07-24-14-471Z.json	18171	SUCCESS	ddcfa393-39ff-4157-bbf7-996f1386fe86	b53635ba-7fac-409d-9de4-c812b2a84263	\N	local	2025-12-09 12:54:14.492265
97785866-ea7a-43cb-b9f2-c8fd2c8f8743	FULL	\N	\N	FAILED	ddcfa393-39ff-4157-bbf7-996f1386fe86	\N	Backup failed: Command failed: "C:\\Program Files\\PostgreSQL\\16\\bin\\pg_dump.exe" -h localhost -p 5432 -U postgres -d cloudledger -F p -f "backups\\full\\cloudledger_full_2025-12-09T07-24-20-849Z.sql"\npg_dump: error: aborting because of server version mismatch\r\npg_dump: detail: server version: 17.2; pg_dump version: 16.9\r\n	local	2025-12-09 12:54:21.02458
5b3c92e4-0138-4033-a70d-04da57edf7d2	FULL	\N	\N	FAILED	ddcfa393-39ff-4157-bbf7-996f1386fe86	\N	Backup failed: Command failed: "C:\\Program Files\\PostgreSQL\\16\\bin\\pg_dump.exe" -h localhost -p 5432 -U postgres -d cloudledger -F p -f "backups\\full\\cloudledger_full_2025-12-09T08-23-39-069Z.sql"\npg_dump: error: aborting because of server version mismatch\r\npg_dump: detail: server version: 17.2; pg_dump version: 16.9\r\n	local	2025-12-09 13:53:39.786163
48f32fde-3de4-4d51-a17e-b051f827eabd	FULL	\N	\N	FAILED	ddcfa393-39ff-4157-bbf7-996f1386fe86	\N	Backup failed: Command failed: "C:\\Program Files\\PostgreSQL\\16\\bin\\pg_dump.exe" -h localhost -p 5432 -U postgres -d cloudledger -F p -f "backups\\full\\cloudledger_full_2025-12-09T08-23-46-333Z.sql"\npg_dump: error: aborting because of server version mismatch\r\npg_dump: detail: server version: 17.2; pg_dump version: 16.9\r\n	local	2025-12-09 13:53:46.468766
4f5c3f63-f45b-4e9f-ab18-b178ac23fd4b	FULL	\N	\N	FAILED	ddcfa393-39ff-4157-bbf7-996f1386fe86	\N	Backup failed: Command failed: "C:\\Program Files\\PostgreSQL\\16\\bin\\pg_dump.exe" -h localhost -p 5432 -U postgres -d cloudledger -F p -f "backups\\full\\cloudledger_full_2025-12-09T08-25-59-558Z.sql"\npg_dump: error: aborting because of server version mismatch\r\npg_dump: detail: server version: 17.2; pg_dump version: 16.9\r\n	local	2025-12-09 13:55:59.993977
36eab9ac-84e6-46a4-8d05-2959cf22d5dc	FULL	\N	\N	FAILED	ddcfa393-39ff-4157-bbf7-996f1386fe86	\N	Backup failed: Command failed: "C:\\Program Files\\PostgreSQL\\16\\bin\\pg_dump.exe" -h localhost -p 5432 -U postgres -d cloudledger -F p -f "backups\\full\\cloudledger_full_2025-12-09T08-30-14-222Z.sql"\npg_dump: error: aborting because of server version mismatch\r\npg_dump: detail: server version: 17.2; pg_dump version: 16.9\r\n	local	2025-12-09 14:00:14.737453
f0998255-dcbf-4c8a-aa6f-7b6fce10c7f9	FULL	\N	\N	FAILED	ddcfa393-39ff-4157-bbf7-996f1386fe86	\N	Backup failed: Command failed: "C:\\Program Files\\PostgreSQL\\16\\bin\\pg_dump.exe" -h localhost -p 5432 -U postgres -d cloudledger -F p -f "backups\\full\\cloudledger_full_2025-12-09T08-35-13-184Z.sql"\npg_dump: error: aborting because of server version mismatch\r\npg_dump: detail: server version: 17.2; pg_dump version: 16.9\r\n	local	2025-12-09 14:05:13.733122
7638af36-1c73-459c-b71c-b8432511f2ba	FULL	\N	\N	FAILED	ddcfa393-39ff-4157-bbf7-996f1386fe86	\N	Backup failed: Command failed: "C:\\Program Files\\PostgreSQL\\16\\bin\\pg_dump.exe" -h localhost -p 5432 -U postgres -d cloudledger -F p -f "backups\\full\\cloudledger_full_2025-12-09T09-22-02-084Z.sql"\npg_dump: error: aborting because of server version mismatch\r\npg_dump: detail: server version: 17.2; pg_dump version: 16.9\r\n	local	2025-12-09 14:52:02.261037
1a39780e-300e-4e33-87ce-be0d7674fd2e	FULL	\N	\N	FAILED	ddcfa393-39ff-4157-bbf7-996f1386fe86	\N	Backup failed: Command failed: "C:\\Program Files\\PostgreSQL\\16\\bin\\pg_dump.exe" -h localhost -p 5432 -U postgres -d cloudledger -F p -f "backups\\full\\cloudledger_full_2025-12-09T09-27-37-486Z.sql"\npg_dump: error: aborting because of server version mismatch\r\npg_dump: detail: server version: 17.2; pg_dump version: 16.9\r\n	local	2025-12-09 14:57:37.681942
4b172cc3-7367-4ce7-aac7-2d9d95a608ae	FULL	\N	\N	FAILED	ddcfa393-39ff-4157-bbf7-996f1386fe86	\N	Backup failed: Command failed: "C:\\Program Files\\PostgreSQL\\16\\bin\\pg_dump.exe" -h localhost -p 5432 -U postgres -d cloudledger -F p -f "backups\\full\\cloudledger_full_2025-12-09T09-27-41-301Z.sql"\npg_dump: error: aborting because of server version mismatch\r\npg_dump: detail: server version: 17.2; pg_dump version: 16.9\r\n	local	2025-12-09 14:57:41.456755
43b19055-174d-41c6-af0f-7b7b154aa79e	FULL	\N	\N	FAILED	ddcfa393-39ff-4157-bbf7-996f1386fe86	\N	Backup failed: Command failed: "C:\\Program Files\\PostgreSQL\\16\\bin\\pg_dump.exe" -h localhost -p 5432 -U postgres -d cloudledger -F p -f "backups\\full\\cloudledger_full_2025-12-09T09-28-14-125Z.sql"\npg_dump: error: aborting because of server version mismatch\r\npg_dump: detail: server version: 17.2; pg_dump version: 16.9\r\n	local	2025-12-09 14:58:14.297178
dcd4d59e-9385-41d9-9dc2-c9a24ba9b057	FULL	\N	\N	FAILED	ddcfa393-39ff-4157-bbf7-996f1386fe86	\N	Backup failed: Command failed: "C:\\Program Files\\PostgreSQL\\16\\bin\\pg_dump.exe" -h localhost -p 5432 -U postgres -d cloudledger -F p -f "backups\\full\\cloudledger_full_2025-12-09T09-28-33-628Z.sql"\npg_dump: error: aborting because of server version mismatch\r\npg_dump: detail: server version: 17.2; pg_dump version: 16.9\r\n	local	2025-12-09 14:58:33.80677
992dba8c-6d0f-468f-a0c1-682c0d5e54d7	FULL	\N	\N	FAILED	ddcfa393-39ff-4157-bbf7-996f1386fe86	\N	Backup failed: Command failed: "C:\\Program Files\\PostgreSQL\\16\\bin\\pg_dump.exe" -h localhost -p 5432 -U postgres -d cloudledger -F p -f "backups\\full\\cloudledger_full_2025-12-09T09-29-15-393Z.sql"\npg_dump: error: aborting because of server version mismatch\r\npg_dump: detail: server version: 17.2; pg_dump version: 16.9\r\n	local	2025-12-09 14:59:15.594066
17e210cb-602f-43bd-ab88-ebab567d0c09	FULL	\N	\N	FAILED	ddcfa393-39ff-4157-bbf7-996f1386fe86	\N	Backup failed: Command failed: "C:\\Program Files\\PostgreSQL\\16\\bin\\pg_dump.exe" -h localhost -p 5432 -U postgres -d cloudledger -F p -f "backups\\full\\cloudledger_full_2025-12-09T09-32-09-225Z.sql"\npg_dump: error: aborting because of server version mismatch\r\npg_dump: detail: server version: 17.2; pg_dump version: 16.9\r\n	local	2025-12-09 15:02:09.430813
ea1b1a0f-8298-44d0-bd78-e0204ca0f083	FULL	\N	\N	FAILED	ddcfa393-39ff-4157-bbf7-996f1386fe86	\N	Backup failed: Command failed: "C:\\Program Files\\PostgreSQL\\16\\bin\\pg_dump.exe" -h localhost -p 5432 -U postgres -d cloudledger -F p -f "backups\\full\\cloudledger_full_2025-12-09T09-32-12-681Z.sql"\npg_dump: error: aborting because of server version mismatch\r\npg_dump: detail: server version: 17.2; pg_dump version: 16.9\r\n	local	2025-12-09 15:02:12.831873
c854fc07-5ed9-41ee-aa05-810a7150f677	FULL	\N	\N	FAILED	ddcfa393-39ff-4157-bbf7-996f1386fe86	\N	Backup failed: Command failed: "C:\\Program Files\\PostgreSQL\\16\\bin\\pg_dump.exe" -h localhost -p 5432 -U postgres -d cloudledger -F p -f "backups\\full\\cloudledger_full_2025-12-09T09-32-29-922Z.sql"\npg_dump: error: aborting because of server version mismatch\r\npg_dump: detail: server version: 17.2; pg_dump version: 16.9\r\n	local	2025-12-09 15:02:30.082201
f20dfff2-df7e-46f6-b42e-9f8ece765b11	FULL	\N	\N	FAILED	ddcfa393-39ff-4157-bbf7-996f1386fe86	\N	Backup failed: Command failed: "C:\\Program Files\\PostgreSQL\\16\\bin\\pg_dump.exe" -h localhost -p 5432 -U postgres -d cloudledger -F p -f "backups\\full\\cloudledger_full_2025-12-09T09-33-54-351Z.sql"\npg_dump: error: aborting because of server version mismatch\r\npg_dump: detail: server version: 17.2; pg_dump version: 16.9\r\n	local	2025-12-09 15:03:54.530941
6c21a49e-ae22-4010-8005-20a2bdda8178	FULL	\N	\N	FAILED	ddcfa393-39ff-4157-bbf7-996f1386fe86	\N	Backup failed: Command failed: "C:\\Program Files\\PostgreSQL\\16\\bin\\pg_dump.exe" -h localhost -p 5432 -U postgres -d cloudledger -F p -f "backups\\full\\cloudledger_full_2025-12-09T09-34-07-946Z.sql"\npg_dump: error: aborting because of server version mismatch\r\npg_dump: detail: server version: 17.2; pg_dump version: 16.9\r\n	local	2025-12-09 15:04:08.091088
3dca89c7-1188-482e-8e7b-b9a6066d1b93	FULL	\N	\N	FAILED	ddcfa393-39ff-4157-bbf7-996f1386fe86	\N	Backup failed: Command failed: "C:\\Program Files\\PostgreSQL\\16\\bin\\pg_dump.exe" -h localhost -p 5432 -U postgres -d cloudledger -F p -f "backups\\full\\cloudledger_full_2025-12-09T09-37-38-061Z.sql"\npg_dump: error: aborting because of server version mismatch\r\npg_dump: detail: server version: 17.2; pg_dump version: 16.9\r\n	local	2025-12-09 15:07:38.243504
eee57e71-125c-47ea-ab94-f973fce620dc	FULL	\N	\N	FAILED	ddcfa393-39ff-4157-bbf7-996f1386fe86	\N	Backup failed: Command failed: "C:\\Program Files\\PostgreSQL\\16\\bin\\pg_dump.exe" -h localhost -p 5432 -U postgres -d cloudledger -F p -f "backups\\full\\cloudledger_full_2025-12-09T09-38-56-102Z.sql"\npg_dump: error: aborting because of server version mismatch\r\npg_dump: detail: server version: 17.2; pg_dump version: 16.9\r\n	local	2025-12-09 15:08:56.261226
d4638d6b-56e0-4a7a-9546-d49f023a910b	FULL	\N	\N	FAILED	ddcfa393-39ff-4157-bbf7-996f1386fe86	\N	Backup failed: Command failed: "C:\\Program Files\\PostgreSQL\\16\\bin\\pg_dump.exe" -h localhost -p 5432 -U postgres -d cloudledger -F p -f "backups\\full\\cloudledger_full_2025-12-09T09-49-05-285Z.sql"\npg_dump: error: aborting because of server version mismatch\r\npg_dump: detail: server version: 17.2; pg_dump version: 16.9\r\n	local	2025-12-09 15:19:05.436487
04cf6906-9df4-438d-988e-1541c2bacb40	FULL	\N	\N	FAILED	ddcfa393-39ff-4157-bbf7-996f1386fe86	\N	Backup failed: Command failed: "C:\\Program Files\\PostgreSQL\\16\\bin\\pg_dump.exe" -h localhost -p 5432 -U postgres -d cloudledger -F p -f "backups\\full\\cloudledger_full_2025-12-09T09-49-32-253Z.sql"\npg_dump: error: aborting because of server version mismatch\r\npg_dump: detail: server version: 17.2; pg_dump version: 16.9\r\n	local	2025-12-09 15:19:32.420846
29be398a-6b45-4b7b-a8ae-ff174a2b97e6	FULL	\N	\N	FAILED	ddcfa393-39ff-4157-bbf7-996f1386fe86	\N	Backup failed: Command failed: "C:\\Program Files\\PostgreSQL\\16\\bin\\pg_dump.exe" -h localhost -p 5432 -U postgres -d cloudledger -F p -f "backups\\full\\cloudledger_full_2025-12-09T09-51-28-515Z.sql"\npg_dump: error: aborting because of server version mismatch\r\npg_dump: detail: server version: 17.2; pg_dump version: 16.9\r\n	local	2025-12-09 15:21:28.716211
020b5ce9-3ad8-474f-8660-c4010d847fee	FULL	\N	\N	FAILED	ddcfa393-39ff-4157-bbf7-996f1386fe86	\N	Backup failed: Command failed: "C:\\Program Files\\PostgreSQL\\16\\bin\\pg_dump.exe" -h localhost -p 5432 -U postgres -d cloudledger -F p -f "backups\\full\\cloudledger_full_2025-12-09T09-51-48-770Z.sql"\npg_dump: error: aborting because of server version mismatch\r\npg_dump: detail: server version: 17.2; pg_dump version: 16.9\r\n	local	2025-12-09 15:21:48.938992
1a276048-4fca-4e23-9592-a94703b2f8e0	FULL	\N	\N	FAILED	ddcfa393-39ff-4157-bbf7-996f1386fe86	\N	Backup failed: Command failed: "C:\\Program Files\\PostgreSQL\\16\\bin\\pg_dump.exe" -h localhost -p 5432 -U postgres -d cloudledger -F p -f "backups\\full\\cloudledger_full_2025-12-09T09-56-29-535Z.sql"\npg_dump: error: aborting because of server version mismatch\r\npg_dump: detail: server version: 17.2; pg_dump version: 16.9\r\n	local	2025-12-09 15:26:29.694986
0f0b1db9-ca0a-4c0f-8f95-73326b1c9c49	FULL	\N	\N	FAILED	ddcfa393-39ff-4157-bbf7-996f1386fe86	\N	Backup failed: Command failed: "C:\\Program Files\\PostgreSQL\\16\\bin\\pg_dump.exe" -h localhost -p 5432 -U postgres -d cloudledger -F p -f "backups\\full\\cloudledger_full_2025-12-09T10-08-10-926Z.sql"\npg_dump: error: aborting because of server version mismatch\r\npg_dump: detail: server version: 17.2; pg_dump version: 16.9\r\n	local	2025-12-09 15:38:11.11287
\.


--
-- Data for Name: companies; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.companies (id, name, address, email, phone, currency, created_at, gstin, state) FROM stdin;
a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11	Demo Company Ltd.	123 Cloud Street, Tech City	info@democompany.com	9876543210	INR	2025-12-02 17:40:37.839221	\N	\N
b53635ba-7fac-409d-9de4-c812b2a84263	Fortune Concept	Ahmedabad 	fortune@gmail.com	9482221459	INR	2025-12-03 10:28:39.848328	\N	\N
\.


--
-- Data for Name: company_users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.company_users (id, company_id, user_id, role) FROM stdin;
a3608d22-f108-40f5-b559-8d569508e011	b53635ba-7fac-409d-9de4-c812b2a84263	ddcfa393-39ff-4157-bbf7-996f1386fe86	admin
\.


--
-- Data for Name: email_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.email_logs (id, invoice_id, recipient, cc, subject, sent_at, status) FROM stdin;
\.


--
-- Data for Name: financial_years; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.financial_years (id, company_id, name, start_date, end_date, is_active, created_at) FROM stdin;
b0eebc99-9c0b-4ef8-bb6d-6bb9bd380a22	a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11	2024-2025	2024-04-01	2025-03-31	t	2025-12-02 17:40:40.128911
00a3c930-22a0-44d9-8613-89420e4a8d3f	b53635ba-7fac-409d-9de4-c812b2a84263	2024-2025	2024-04-01	2025-03-31	t	2025-12-03 10:28:39.848328
\.


--
-- Data for Name: invoice_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.invoice_items (id, invoice_id, item_id, description, quantity, rate, amount, tax_rate, tax_amount, created_at, discount_percent, discount_amount, cgst_rate, cgst_amount, sgst_rate, sgst_amount, igst_rate, igst_amount, taxable_amount, total_amount) FROM stdin;
5328bc10-e9fb-4760-b2c0-b4d14b136c0b	27394c80-b3da-4350-9a7d-77bb179c094f	1a94f177-41ae-4003-8dc1-a85dcb03cad6	Dell laptop	5.000	9500.00	47500.00	18.00	8550.00	2025-12-03 15:45:17.240647	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00
422132d7-37a6-4172-b799-6e156e0e5b60	270d4b52-6c51-41cd-9f08-45580f9238a5	1a94f177-41ae-4003-8dc1-a85dcb03cad6	Dell laptop	1.000	10000.00	10000.00	18.00	1800.00	2025-12-03 15:52:45.082654	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00
b66d5791-be14-4635-9fb1-082a7b0b803a	3a5853ab-eb4e-44e5-afa0-ab27a901d7b8	1a94f177-41ae-4003-8dc1-a85dcb03cad6	Dell laptop	1.000	10000.00	10000.00	0.00	0.00	2025-12-04 11:33:18.571666	5.00	500.00	0.00	0.00	0.00	0.00	0.00	0.00	9500.00	9500.00
a9fb3b90-a334-45f8-9e37-75a1768806e7	3a5853ab-eb4e-44e5-afa0-ab27a901d7b8	1a94f177-41ae-4003-8dc1-a85dcb03cad6	Dell laptop	1.000	10000.00	10000.00	0.00	0.00	2025-12-04 11:33:18.571666	0.00	0.00	0.00	0.00	0.00	0.00	18.00	1800.00	10000.00	11800.00
a2086b87-40cd-4d15-b962-3576248fb053	feb5d1dd-ebfa-4f11-875b-2b48c27f9248	1a94f177-41ae-4003-8dc1-a85dcb03cad6	Dell laptop	1.000	10000.00	10000.00	18.00	0.00	2025-12-04 12:54:20.072932	2.00	200.00	0.00	0.00	0.00	0.00	18.00	1764.00	9800.00	11564.00
0b295105-7785-419e-a8e4-ee2df97f77ff	13a53842-f0ab-463c-ac3f-cf4c2f361449	1a94f177-41ae-4003-8dc1-a85dcb03cad6	Dell laptop	1.000	10000.00	10000.00	18.00	0.00	2025-12-04 13:22:21.633306	5.00	500.00	9.00	855.00	9.00	855.00	0.00	0.00	9500.00	11210.00
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.invoices (id, company_id, voucher_id, party_ledger_id, sales_ledger_id, invoice_number, date, due_date, type, subtotal, tax_total, grand_total, notes, created_at, discount_percent, discount_amount, paid_amount, outstanding_amount, payment_status) FROM stdin;
27394c80-b3da-4350-9a7d-77bb179c094f	b53635ba-7fac-409d-9de4-c812b2a84263	1278bc3c-a7bc-4c1a-80ec-e9eae0f3c385	9e955edf-ad4d-4efd-acbd-2384e5cf110e	0ddd8f3b-8153-4a51-abdb-334f6d80b8b2	ADC123	2025-12-03	2025-12-03	PURCHASE	47500.00	8550.00	56050.00		2025-12-03 15:45:17.240647	0.00	0.00	0.00	0.00	UNPAID
270d4b52-6c51-41cd-9f08-45580f9238a5	b53635ba-7fac-409d-9de4-c812b2a84263	c603218e-e07c-4e98-a003-6a9f504febad	9e955edf-ad4d-4efd-acbd-2384e5cf110e	fe7a596f-8b70-40ff-b5f5-a5385ed70c92	DSS234	2025-12-03	2025-12-03	SALES	10000.00	1800.00	11800.00		2025-12-03 15:52:45.082654	0.00	0.00	0.00	0.00	UNPAID
3a5853ab-eb4e-44e5-afa0-ab27a901d7b8	b53635ba-7fac-409d-9de4-c812b2a84263	016514b6-75fc-4127-893c-466965f6a204	9e955edf-ad4d-4efd-acbd-2384e5cf110e	fe7a596f-8b70-40ff-b5f5-a5385ed70c92	ERR789	2025-12-02	2025-12-02	SALES	19500.00	1800.00	21300.00		2025-12-04 11:28:43.887286	0.00	0.00	0.00	21300.00	UNPAID
feb5d1dd-ebfa-4f11-875b-2b48c27f9248	b53635ba-7fac-409d-9de4-c812b2a84263	58b47dcb-c186-42b2-bcdf-8e60c168e74b	9e955edf-ad4d-4efd-acbd-2384e5cf110e	fe7a596f-8b70-40ff-b5f5-a5385ed70c92	WWW890	2025-12-03	2025-12-03	SALES	9800.00	1764.00	11564.00		2025-12-04 11:39:22.920987	0.00	0.00	0.00	11564.00	UNPAID
13a53842-f0ab-463c-ac3f-cf4c2f361449	b53635ba-7fac-409d-9de4-c812b2a84263	5e653482-7f80-4c25-82d2-0745fc4e41cb	9e955edf-ad4d-4efd-acbd-2384e5cf110e	fe7a596f-8b70-40ff-b5f5-a5385ed70c92	ETT894	2025-12-03	2025-12-03	SALES	9500.00	1710.00	11210.00		2025-12-04 12:55:34.345931	0.00	0.00	0.00	11210.00	UNPAID
\.


--
-- Data for Name: items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.items (id, company_id, name, hsn_code, unit_id, description, tax_rate, sales_rate, purchase_rate, opening_quantity, current_quantity, created_at) FROM stdin;
1a94f177-41ae-4003-8dc1-a85dcb03cad6	b53635ba-7fac-409d-9de4-c812b2a84263	Dell laptop	84211960	e4532858-0759-44a5-955f-505171ddd9fc	\N	18.00	10000.00	9500.00	5.000	5.000	2025-12-03 15:28:26.831154
\.


--
-- Data for Name: ledger_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ledger_groups (id, company_id, name, parent_id, type, created_at) FROM stdin;
c0eebc99-9c0b-4ef8-bb6d-6bb9bd380a33	a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11	Assets	\N	Asset	2025-12-02 17:40:42.550259
d0eebc99-9c0b-4ef8-bb6d-6bb9bd380a44	a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11	Liabilities	\N	Liability	2025-12-02 17:40:42.550259
e0eebc99-9c0b-4ef8-bb6d-6bb9bd380a55	a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11	Income	\N	Income	2025-12-02 17:40:42.550259
f0eebc99-9c0b-4ef8-bb6d-6bb9bd380a66	a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11	Expenses	\N	Expense	2025-12-02 17:40:42.550259
44bc3050-7808-4081-b4af-52834a516f57	a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11	Current Assets	c0eebc99-9c0b-4ef8-bb6d-6bb9bd380a33	Asset	2025-12-02 17:40:45.008898
7102039f-9224-43bb-93ef-4eaf71be33be	a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11	Bank Accounts	c0eebc99-9c0b-4ef8-bb6d-6bb9bd380a33	Asset	2025-12-02 17:40:45.008898
6457703e-a95e-4523-95a1-4892d8f0b18b	a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11	Cash-in-Hand	c0eebc99-9c0b-4ef8-bb6d-6bb9bd380a33	Asset	2025-12-02 17:40:45.008898
beec5716-9a33-42c6-9815-c02043b2b527	a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11	Sundry Debtors	c0eebc99-9c0b-4ef8-bb6d-6bb9bd380a33	Asset	2025-12-02 17:40:45.008898
d1714e49-3411-456c-a74b-b542eac0e21b	a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11	Sundry Creditors	d0eebc99-9c0b-4ef8-bb6d-6bb9bd380a44	Liability	2025-12-02 17:40:45.008898
b6700df6-df02-4443-bb16-bd078b684c33	a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11	Sales Accounts	e0eebc99-9c0b-4ef8-bb6d-6bb9bd380a55	Income	2025-12-02 17:40:45.008898
9c042482-8985-45a2-ba86-ce0473a5ca64	a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11	Purchase Accounts	f0eebc99-9c0b-4ef8-bb6d-6bb9bd380a66	Expense	2025-12-02 17:40:45.008898
cd528726-805c-40df-950b-892efb5c43dc	b53635ba-7fac-409d-9de4-c812b2a84263	Assets	\N	Asset	2025-12-03 10:28:39.848328
9da583c0-da0b-4050-b751-a4bc692de194	b53635ba-7fac-409d-9de4-c812b2a84263	Liabilities	\N	Liability	2025-12-03 10:28:39.848328
ac1e6cd8-fc82-4b18-9c79-7ff3e739b54b	b53635ba-7fac-409d-9de4-c812b2a84263	Income	\N	Income	2025-12-03 10:28:39.848328
0b6176e9-5e8f-45fc-a63d-befd6156797b	b53635ba-7fac-409d-9de4-c812b2a84263	Expenses	\N	Expense	2025-12-03 10:28:39.848328
\.


--
-- Data for Name: ledgers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ledgers (id, company_id, group_id, name, opening_balance, opening_balance_type, current_balance, created_at, gstin, state) FROM stdin;
9e955edf-ad4d-4efd-acbd-2384e5cf110e	b53635ba-7fac-409d-9de4-c812b2a84263	0b6176e9-5e8f-45fc-a63d-befd6156797b	Customer	1000.00	Dr	0.00	2025-12-03 10:30:22.925628	\N	\N
0ddd8f3b-8153-4a51-abdb-334f6d80b8b2	b53635ba-7fac-409d-9de4-c812b2a84263	9da583c0-da0b-4050-b751-a4bc692de194	Purchases	0.00	Dr	0.00	2025-12-03 15:34:07.923176	\N	\N
fe7a596f-8b70-40ff-b5f5-a5385ed70c92	b53635ba-7fac-409d-9de4-c812b2a84263	9da583c0-da0b-4050-b751-a4bc692de194	Sales	0.00	Cr	0.00	2025-12-03 15:34:41.753367	\N	\N
a11f04aa-d793-4976-9c96-661f4bd091a9	b53635ba-7fac-409d-9de4-c812b2a84263	9da583c0-da0b-4050-b751-a4bc692de194	GST	0.00	Dr	0.00	2025-12-03 15:48:07.240179	\N	\N
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payments (id, company_id, invoice_id, voucher_id, payment_date, amount, payment_mode, reference_number, notes, created_at) FROM stdin;
\.


--
-- Data for Name: recurring_invoice_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.recurring_invoice_items (id, recurring_invoice_id, item_id, description, quantity, rate, discount_percent) FROM stdin;
\.


--
-- Data for Name: recurring_invoices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.recurring_invoices (id, company_id, party_ledger_id, sales_ledger_id, type, frequency, start_date, end_date, next_invoice_date, invoice_number_prefix, discount_percent, notes, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: restore_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.restore_logs (id, backup_filename, type, status, restored_by, error_message, created_at) FROM stdin;
\.


--
-- Data for Name: units; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.units (id, company_id, name, symbol, created_at) FROM stdin;
40d6ab6d-76fe-4f1f-b4f1-51ddf383fad3	b53635ba-7fac-409d-9de4-c812b2a84263	Test Unit	TU	2025-12-03 13:22:54.020106
e4532858-0759-44a5-955f-505171ddd9fc	b53635ba-7fac-409d-9de4-c812b2a84263	Pieces 	Pcs	2025-12-04 16:35:33.007863
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, name, email, password, role, created_at) FROM stdin;
ddcfa393-39ff-4157-bbf7-996f1386fe86	Harsh Shah	harsh@gmail.com	$2b$10$Q6/HambN7mHIEhgo7hHpku7Ph89fBdetoqdG4FIt6EwIjuic7yVrG	admin	2025-12-03 09:48:02.334364
\.


--
-- Data for Name: voucher_entries; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.voucher_entries (id, voucher_id, ledger_id, amount, type, created_at) FROM stdin;
9116326a-85ba-4fc1-bb61-210d7c0f9a64	ecb9db43-7bee-47b6-83a2-56a4e5c0e12c	9e955edf-ad4d-4efd-acbd-2384e5cf110e	123.00	Dr	2025-12-03 10:44:19.163282
cd4c322e-575c-41ca-b6dc-08e9732fe89a	ecb9db43-7bee-47b6-83a2-56a4e5c0e12c	9e955edf-ad4d-4efd-acbd-2384e5cf110e	123.00	Cr	2025-12-03 10:44:19.163282
68585a73-e36c-45cf-a3be-d1feecfd475e	1278bc3c-a7bc-4c1a-80ec-e9eae0f3c385	9e955edf-ad4d-4efd-acbd-2384e5cf110e	56050.00	Cr	2025-12-03 15:45:17.240647
651427d8-9915-4bcd-8acd-a9b2f7ec8d3b	1278bc3c-a7bc-4c1a-80ec-e9eae0f3c385	0ddd8f3b-8153-4a51-abdb-334f6d80b8b2	47500.00	Dr	2025-12-03 15:45:17.240647
374f6792-b8dc-4763-b2d0-6668fb6579cc	c603218e-e07c-4e98-a003-6a9f504febad	9e955edf-ad4d-4efd-acbd-2384e5cf110e	11800.00	Dr	2025-12-03 15:52:45.082654
34fa284f-6a73-4575-b1c7-c914ce2b18b5	c603218e-e07c-4e98-a003-6a9f504febad	fe7a596f-8b70-40ff-b5f5-a5385ed70c92	10000.00	Cr	2025-12-03 15:52:45.082654
89f5c5e0-5b06-4a39-a207-435688300565	c603218e-e07c-4e98-a003-6a9f504febad	a11f04aa-d793-4976-9c96-661f4bd091a9	1800.00	Cr	2025-12-03 15:52:45.082654
ef70b60f-3a05-4fd8-b7b0-37d7ef50251a	016514b6-75fc-4127-893c-466965f6a204	9e955edf-ad4d-4efd-acbd-2384e5cf110e	21300.00	Dr	2025-12-04 11:33:18.571666
6fcb583e-fd08-4aef-b371-a03a6c41af29	016514b6-75fc-4127-893c-466965f6a204	fe7a596f-8b70-40ff-b5f5-a5385ed70c92	19500.00	Cr	2025-12-04 11:33:18.571666
28d06e0c-f7dc-482e-b3a8-113b92b4cb6f	58b47dcb-c186-42b2-bcdf-8e60c168e74b	9e955edf-ad4d-4efd-acbd-2384e5cf110e	11564.00	Dr	2025-12-04 12:54:20.072932
3941a84c-1405-490b-a61e-1f42417e6a4e	58b47dcb-c186-42b2-bcdf-8e60c168e74b	fe7a596f-8b70-40ff-b5f5-a5385ed70c92	9800.00	Cr	2025-12-04 12:54:20.072932
0ba8684d-12e6-4708-898f-a6a1a143fa0e	5e653482-7f80-4c25-82d2-0745fc4e41cb	9e955edf-ad4d-4efd-acbd-2384e5cf110e	11210.00	Dr	2025-12-04 13:22:21.633306
5d6b665b-1c17-4277-a8c8-f391f703b046	5e653482-7f80-4c25-82d2-0745fc4e41cb	fe7a596f-8b70-40ff-b5f5-a5385ed70c92	9500.00	Cr	2025-12-04 13:22:21.633306
\.


--
-- Data for Name: voucher_types; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.voucher_types (id, company_id, name, created_at) FROM stdin;
29ada5a2-db0d-4381-a3d4-3426983b03b6	a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11	Sales	2025-12-02 17:40:47.190595
235c3327-30b2-445e-9cd9-07d6d7d21dda	a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11	Purchase	2025-12-02 17:40:47.190595
59314da6-169a-4c74-bf7d-6711c58cfa59	a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11	Payment	2025-12-02 17:40:47.190595
6b1347f6-280e-4068-8cc3-cd030c8f9d8e	a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11	Receipt	2025-12-02 17:40:47.190595
62eb9f6e-f3dc-4e10-ac68-007686499b62	a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11	Journal	2025-12-02 17:40:47.190595
4ff6de0c-d94d-4bfa-9fd3-9afb136d6437	b53635ba-7fac-409d-9de4-c812b2a84263	Sales	2025-12-03 10:28:39.848328
8c5118dc-bc20-4297-8a0b-ecfe7173e7c4	b53635ba-7fac-409d-9de4-c812b2a84263	Purchase	2025-12-03 10:28:39.848328
b0a76c29-2faf-4ca1-ba48-d81b9830547f	b53635ba-7fac-409d-9de4-c812b2a84263	Payment	2025-12-03 10:28:39.848328
8011383e-751b-4a8b-8637-7bc7543dc32e	b53635ba-7fac-409d-9de4-c812b2a84263	Receipt	2025-12-03 10:28:39.848328
bbeb5133-9646-4387-acf5-55c197e63815	b53635ba-7fac-409d-9de4-c812b2a84263	Journal	2025-12-03 10:28:39.848328
\.


--
-- Data for Name: vouchers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vouchers (id, company_id, financial_year_id, voucher_type_id, voucher_number, date, narration, total_amount, created_at) FROM stdin;
ecb9db43-7bee-47b6-83a2-56a4e5c0e12c	b53635ba-7fac-409d-9de4-c812b2a84263	\N	4ff6de0c-d94d-4bfa-9fd3-9afb136d6437	ABC123	2025-12-03		123.00	2025-12-03 10:44:19.163282
1278bc3c-a7bc-4c1a-80ec-e9eae0f3c385	b53635ba-7fac-409d-9de4-c812b2a84263	\N	8c5118dc-bc20-4297-8a0b-ecfe7173e7c4	ADC123	2025-12-03	Invoice #ADC123 - 	56050.00	2025-12-03 15:45:17.240647
c603218e-e07c-4e98-a003-6a9f504febad	b53635ba-7fac-409d-9de4-c812b2a84263	\N	4ff6de0c-d94d-4bfa-9fd3-9afb136d6437	DSS234	2025-12-03	Invoice #DSS234 - 	11800.00	2025-12-03 15:52:45.082654
016514b6-75fc-4127-893c-466965f6a204	b53635ba-7fac-409d-9de4-c812b2a84263	\N	4ff6de0c-d94d-4bfa-9fd3-9afb136d6437	ERR789	2025-12-02	Invoice #ERR789 - 	21300.00	2025-12-04 11:28:43.887286
58b47dcb-c186-42b2-bcdf-8e60c168e74b	b53635ba-7fac-409d-9de4-c812b2a84263	\N	4ff6de0c-d94d-4bfa-9fd3-9afb136d6437	WWW890	2025-12-03	Invoice #WWW890 - 	11564.00	2025-12-04 11:39:22.920987
5e653482-7f80-4c25-82d2-0745fc4e41cb	b53635ba-7fac-409d-9de4-c812b2a84263	\N	4ff6de0c-d94d-4bfa-9fd3-9afb136d6437	ETT894	2025-12-03	Invoice #ETT894 - 	11210.00	2025-12-04 12:55:34.345931
\.


--
-- Name: backup_logs backup_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.backup_logs
    ADD CONSTRAINT backup_logs_pkey PRIMARY KEY (id);


--
-- Name: companies companies_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_pkey PRIMARY KEY (id);


--
-- Name: company_users company_users_company_id_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.company_users
    ADD CONSTRAINT company_users_company_id_user_id_key UNIQUE (company_id, user_id);


--
-- Name: company_users company_users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.company_users
    ADD CONSTRAINT company_users_pkey PRIMARY KEY (id);


--
-- Name: email_logs email_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.email_logs
    ADD CONSTRAINT email_logs_pkey PRIMARY KEY (id);


--
-- Name: financial_years financial_years_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.financial_years
    ADD CONSTRAINT financial_years_pkey PRIMARY KEY (id);


--
-- Name: invoice_items invoice_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoice_items
    ADD CONSTRAINT invoice_items_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: items items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_pkey PRIMARY KEY (id);


--
-- Name: ledger_groups ledger_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ledger_groups
    ADD CONSTRAINT ledger_groups_pkey PRIMARY KEY (id);


--
-- Name: ledgers ledgers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ledgers
    ADD CONSTRAINT ledgers_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: recurring_invoice_items recurring_invoice_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recurring_invoice_items
    ADD CONSTRAINT recurring_invoice_items_pkey PRIMARY KEY (id);


--
-- Name: recurring_invoices recurring_invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recurring_invoices
    ADD CONSTRAINT recurring_invoices_pkey PRIMARY KEY (id);


--
-- Name: restore_logs restore_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.restore_logs
    ADD CONSTRAINT restore_logs_pkey PRIMARY KEY (id);


--
-- Name: units units_company_id_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.units
    ADD CONSTRAINT units_company_id_name_key UNIQUE (company_id, name);


--
-- Name: units units_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.units
    ADD CONSTRAINT units_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: voucher_entries voucher_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.voucher_entries
    ADD CONSTRAINT voucher_entries_pkey PRIMARY KEY (id);


--
-- Name: voucher_types voucher_types_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.voucher_types
    ADD CONSTRAINT voucher_types_pkey PRIMARY KEY (id);


--
-- Name: vouchers vouchers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vouchers
    ADD CONSTRAINT vouchers_pkey PRIMARY KEY (id);


--
-- Name: idx_backup_logs_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_backup_logs_created ON public.backup_logs USING btree (created_at);


--
-- Name: idx_backup_logs_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_backup_logs_status ON public.backup_logs USING btree (status);


--
-- Name: idx_backup_logs_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_backup_logs_type ON public.backup_logs USING btree (type);


--
-- Name: idx_email_logs_invoice; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_email_logs_invoice ON public.email_logs USING btree (invoice_id);


--
-- Name: idx_invoice_items_invoice; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_invoice_items_invoice ON public.invoice_items USING btree (invoice_id);


--
-- Name: idx_invoices_company; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_invoices_company ON public.invoices USING btree (company_id);


--
-- Name: idx_invoices_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_invoices_date ON public.invoices USING btree (date);


--
-- Name: idx_items_company; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_items_company ON public.items USING btree (company_id);


--
-- Name: idx_payments_company; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_payments_company ON public.payments USING btree (company_id);


--
-- Name: idx_payments_invoice; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_payments_invoice ON public.payments USING btree (invoice_id);


--
-- Name: idx_recurring_invoices_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_recurring_invoices_active ON public.recurring_invoices USING btree (is_active);


--
-- Name: idx_recurring_invoices_company; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_recurring_invoices_company ON public.recurring_invoices USING btree (company_id);


--
-- Name: idx_recurring_invoices_next_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_recurring_invoices_next_date ON public.recurring_invoices USING btree (next_invoice_date);


--
-- Name: idx_restore_logs_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_restore_logs_created ON public.restore_logs USING btree (created_at);


--
-- Name: backup_logs backup_logs_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.backup_logs
    ADD CONSTRAINT backup_logs_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE SET NULL;


--
-- Name: backup_logs backup_logs_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.backup_logs
    ADD CONSTRAINT backup_logs_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: company_users company_users_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.company_users
    ADD CONSTRAINT company_users_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: company_users company_users_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.company_users
    ADD CONSTRAINT company_users_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: email_logs email_logs_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.email_logs
    ADD CONSTRAINT email_logs_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoices(id) ON DELETE SET NULL;


--
-- Name: financial_years financial_years_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.financial_years
    ADD CONSTRAINT financial_years_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: invoice_items invoice_items_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoice_items
    ADD CONSTRAINT invoice_items_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoices(id) ON DELETE CASCADE;


--
-- Name: invoice_items invoice_items_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoice_items
    ADD CONSTRAINT invoice_items_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE SET NULL;


--
-- Name: invoices invoices_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: invoices invoices_party_ledger_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_party_ledger_id_fkey FOREIGN KEY (party_ledger_id) REFERENCES public.ledgers(id) ON DELETE SET NULL;


--
-- Name: invoices invoices_sales_ledger_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_sales_ledger_id_fkey FOREIGN KEY (sales_ledger_id) REFERENCES public.ledgers(id) ON DELETE SET NULL;


--
-- Name: invoices invoices_voucher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_voucher_id_fkey FOREIGN KEY (voucher_id) REFERENCES public.vouchers(id) ON DELETE SET NULL;


--
-- Name: items items_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: items items_unit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_unit_id_fkey FOREIGN KEY (unit_id) REFERENCES public.units(id) ON DELETE SET NULL;


--
-- Name: ledger_groups ledger_groups_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ledger_groups
    ADD CONSTRAINT ledger_groups_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: ledger_groups ledger_groups_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ledger_groups
    ADD CONSTRAINT ledger_groups_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.ledger_groups(id) ON DELETE SET NULL;


--
-- Name: ledgers ledgers_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ledgers
    ADD CONSTRAINT ledgers_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: ledgers ledgers_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ledgers
    ADD CONSTRAINT ledgers_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.ledger_groups(id) ON DELETE SET NULL;


--
-- Name: payments payments_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: payments payments_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoices(id) ON DELETE CASCADE;


--
-- Name: payments payments_voucher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_voucher_id_fkey FOREIGN KEY (voucher_id) REFERENCES public.vouchers(id) ON DELETE SET NULL;


--
-- Name: recurring_invoice_items recurring_invoice_items_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recurring_invoice_items
    ADD CONSTRAINT recurring_invoice_items_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id);


--
-- Name: recurring_invoice_items recurring_invoice_items_recurring_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recurring_invoice_items
    ADD CONSTRAINT recurring_invoice_items_recurring_invoice_id_fkey FOREIGN KEY (recurring_invoice_id) REFERENCES public.recurring_invoices(id) ON DELETE CASCADE;


--
-- Name: recurring_invoices recurring_invoices_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recurring_invoices
    ADD CONSTRAINT recurring_invoices_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: recurring_invoices recurring_invoices_party_ledger_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recurring_invoices
    ADD CONSTRAINT recurring_invoices_party_ledger_id_fkey FOREIGN KEY (party_ledger_id) REFERENCES public.ledgers(id);


--
-- Name: recurring_invoices recurring_invoices_sales_ledger_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recurring_invoices
    ADD CONSTRAINT recurring_invoices_sales_ledger_id_fkey FOREIGN KEY (sales_ledger_id) REFERENCES public.ledgers(id);


--
-- Name: restore_logs restore_logs_restored_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.restore_logs
    ADD CONSTRAINT restore_logs_restored_by_fkey FOREIGN KEY (restored_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: units units_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.units
    ADD CONSTRAINT units_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: voucher_entries voucher_entries_ledger_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.voucher_entries
    ADD CONSTRAINT voucher_entries_ledger_id_fkey FOREIGN KEY (ledger_id) REFERENCES public.ledgers(id) ON DELETE CASCADE;


--
-- Name: voucher_entries voucher_entries_voucher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.voucher_entries
    ADD CONSTRAINT voucher_entries_voucher_id_fkey FOREIGN KEY (voucher_id) REFERENCES public.vouchers(id) ON DELETE CASCADE;


--
-- Name: voucher_types voucher_types_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.voucher_types
    ADD CONSTRAINT voucher_types_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: vouchers vouchers_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vouchers
    ADD CONSTRAINT vouchers_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: vouchers vouchers_financial_year_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vouchers
    ADD CONSTRAINT vouchers_financial_year_id_fkey FOREIGN KEY (financial_year_id) REFERENCES public.financial_years(id) ON DELETE SET NULL;


--
-- Name: vouchers vouchers_voucher_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vouchers
    ADD CONSTRAINT vouchers_voucher_type_id_fkey FOREIGN KEY (voucher_type_id) REFERENCES public.voucher_types(id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

